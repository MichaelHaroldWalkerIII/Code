#Stack
#
# CS3021 LL Project


import LinkedList

class Stack(object):
    ''' Implement, you will need to call appropriate LinkedList functionality.
        Do not write code to duplicate any LL behaviors in this file
        Do not change LinkedList. '''


    def __init__(self):
        self.__q = None     #Stack has-a linked-list, None means the list is empty
        self.__size = 0



    def push(self, dataItem):
        #TODO   implement, ensure you handle empty list cases
        if self.head is None:
            self.head = Node(dataItem)
        else:
            new_node = Node(dataItem)
            new_node.next = self.head
            self.head = new_node
        pass






    def pop(self):
        #TODO   implement, ensure you handle empty list cases
        if self.head is None:
            return None
        else:
            popped = self.head.data
            self.head = self.head.next
            return popped
        pass






    def __str__(self):
        #TODO   implement, ensure you handle empty list cases
        return str(self.temp)
        pass




##########################################################
#main


if __name__=="__main__":
    s = Stack()
    print(s)


    s.push(0)
    print('push(0)', s)

    result = s.pop()
    print('pop():', result, '    q:', s)

    s.push(10)
    print('push(10)', s)

    s.push(1)
    print('push(1)', s)

    s.push(2)
    print('push(2)', s)

    result = s.pop()
    print('pop():', result, '    q:', s)

    s.push(22)
    print('push(22)', s)

    result = s.pop()
    print('pop():', result, '    q:', s)
    result = s.pop()
    print('pop():', result, '    q:', s)
    result = s.pop()
    print('pop():', result, '    q:', s)
    result = s.pop()
    print('pop():', result, '    q:', s)
