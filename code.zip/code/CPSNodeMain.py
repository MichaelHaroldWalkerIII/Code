#Beau Reimer
#Joe Pasion
#Michael Walker

#!/usr/bin/python

import multiprocessing
import tempNode_lab2 as tNode
import client_node_class as cNode
import sys

argv = sys.argv
gw = ""
for item in argv:
    param = item.split("=")
    if param[0].strip() == "gwaddress":
        gw = param[1].strip()

def startTempNode(tnode):
    tnode.startNode()

def startClientNode(cnode):
    cnode.handshake()

tempQ = multiprocessing.Queue()
cmdQ = multiprocessing.Queue()
e = multiprocessing.Event()

t = tNode.CPSTempNode(tempQ,cmdQ, e)
if not gw == "":
    c = cNode.ClientNode(tempQ,cmdQ, e, gwaddress = gw)
else:
    c = cNode.ClientNode(tempQ,cmdQ, e)

tNode = multiprocessing.Process(target=startTempNode, args=(t,))
tNode.start()
cNode = multiprocessing.Process(target=startClientNode, args=(c,))
cNode.start()

cNode.join()
print("ClientNode joined, waiting on tempNode")
tNode.join()
print("TempNode joined, exiting")
