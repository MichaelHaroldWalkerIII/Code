#Beau Reimer
#Joe Pasion
#Michael Walker

#!/usr/bin/python
#based on: https://github.com/SamuelKinnett/python-network-guessing-game/blob/master/multithreaded/guessing-game-client.py
from socket import *
import sys
import time
import os
from uuid import getnode as get_mac

#globals
BAD=1
GOOD=0

#subs
def rcv(clientsocket):
    response=""
    error=False
    try:
       responsePkt = clientsocket.recv(1024)
       response = responsePkt.decode('ascii')
    except:
        error=True
        print "\n\nERROR: connection socket related\n\n...exiting...\n\n"
    return (error, response)
def snd(clientsocket, msg):
    error=False
    error=False
    try:
        clientsocket.send(msg.encode('ascii'))
    except:
        error=True
        print "\n\nERROR: connection socket related\n\n...exiting...\n\n"
    return error
def getMac():
   #check macaddress #from: https://stackoverflow.com/questions/159137/getting-mac-address
   mac=get_mac()
   msg=':'.join(("%012X" % mac)[i:i+2] for i in range(0, 12, 2))
   return msg
def mainClient():
   isOK=BAD
   mac=getMac()
   print "DEBUG mainClient: mac="+str(mac)

   # Set up the socket as an Internet facing streaming socket
   clientsocket = socket(AF_INET, SOCK_STREAM)
   # Connect to the server on port 4000
   try:
      clientsocket.connect(('localhost', 4000))
      #clientsocket.connect(('172.20.107.255', 4000))
   #except socket.error:
   except socket:
      print "Error: socket.error"
      os._exit(0)
   except: 
      print "Error: general connection error"
      os._exit(0)
   print("connected!")
   # Send the greeting message to the server, as specified by the requirements
   msg = "Node: "+str(mac)
   #clientsocket.send(message.encode('ascii'))
   error = snd(clientsocket,msg)
   if(error):
      clientsocket.close()
      return


   #initial connection ready, now run continuously
   running = 1
   cnt=0
   while running:
      cnt=cnt+1
      #print "DEBUG while cnt="+str(cnt)

      # Wait for the response from the server
      #receive command; command packet=="command: <command>" , where command=(-1==FANOFF, -2==FANON, temp==tempSetpoint)
      (error, serverPkt) = rcv(clientsocket)
      (error, tempPkt) = snd(serversocket)
      if(error):
         running=0
         continue
      if(serverPkt=="servuser: EXIT"):
          print "server Exit"
          os._exit(0)
      header=serverPkt.split(" ")[0]
      headerLen=len(header)
      msg=serverPkt[headerLen:]
      msgLen=len(msg)

      sys.stdout.write(msg)
      
      #reply to server
      #header=header+" " -- we will not put the space back into the header/packet
      if(header == "commandViewTemps:"):
          error = snd(clientsocket,header+"NoResponse")
          
      command = changeNodeTempGetCmd(node, temp)
      error = rcv("Command: "+command, serversocket)
      if(error):
          running=0
          continue
      else:
          msg = raw_input(msg)
          msg=header+msg
          error = snd(clientsocket,msg)
          if(error):
             clientsocket.close()
             return

      #sleep
      time.sleep(1.0)

   clientsocket.close()
   return

if __name__ == "__main__":
   print("starting..")
   try:
      mainClient()
   except KeyboardInterrupt:
      os._exit(0)
