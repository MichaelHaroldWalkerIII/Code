#FIFO Queue
#
# CS3021 LL Project

import LinkedList

class FIFO(object):
    ''' Implement, you will need to call appropriate LinkedList functionality.
        Do not write code to duplicate any LL behaviors in this file
        Do not change LinkedList. '''

    def __init__(self):
        self.__q = None   #FIFO has-a linked-list, None means the list is empty
        self.__size = 0



    def add(self, dataItem):
        #TODO   implement, ensure you handle empty list cases
        new_item = Node(dataItem)
        current = self.head
        if current is None:
            self._q = new_item
        else:
            while current.get_next():
                current = current.get_next()
            current.set_next(new_item)
        pass



    def remove(self):
        #TODO   implement, ensure you handle empty list cases
        current = self.head
        if current != None:
            self._q = current.get_next()
        else:
            print("Queue is empty.")
        pass



    def __str__(self):
        #TODO   implement, ensure you handle empty list cases
        return str(self.temp)
        pass



##########################################################
#main


if __name__=="__main__":
    fifo = FIFO()
    print(fifo)

    fifo.add(0)
    print('add(0)', fifo)

    fifo.add(1)
    print('add(1)', fifo)
    fifo.add(2)
    print('add(2)', fifo)

    removed = fifo.remove()
    print('removed:', removed, '  q:', fifo)
    removed = fifo.remove()
    print('removed:', removed, '  q:', fifo)
    removed = fifo.remove()
    print('removed:', removed, '  q:', fifo)
    removed = fifo.remove()
    print('removed:', removed, '  q:', fifo)
