import copy
from Utility import *
from Point import *

        


class Rectangle(object):

    def __init__(self, locationIn, heightIn, widthIn):
     
        self.setLocation(locationIn)
        self.setHeight(heightIn)
        self.setWidth(widthIn)
    
    def setLocation(self, locationIn):
        if not isinstance(locationIn, Point):
            raise RuntimeError(str(locationIn) + ' is not a Point')
        self.location = locationIn

    def setHeight(self, heightIn):
        self.height = checkNumeric(heightIn)


    def setWidth(self, widthIn):
        self.width = checkNumeric(widthIn)

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.__dict__ == other.__dict__
        return NotImplemented

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            answer = True
            if not self.height == other.height:
                answer = False
            if not self.width == other.width:
                answer = False
            return answer
        return NotImplemented

    def __ne__(self, other):
        if isinstance(other, self.__class__):
            answer = True
            if self.height == other.height:
                answer = False
            if self.width == other.width:
                answer = False
            return answer
        return NotImplemented

    def __hash__(self):
        return hash(tuple( sorted( self.__dict__.items() )))
