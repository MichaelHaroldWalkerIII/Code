#Beau Reimer
#Joe Pasion
#Michael Walker

#!/usr/bin/python
#based on: https://github.com/SamuelKinnett/python-network-guessing-game/blob/master/multithreaded/guessing-game-client.py
from socket import *
import sys
import time
import os
from uuid import getnode as get_mac
import logging
import logging.handlers
import logging.config
from  multiprocessing import Queue


class ClientNode:

    def __init__(self, tqueue, cmdqueue, exitEvent, gwaddress = 'localhost', gwport=4000, loginit=""):

        self.tempQ = tqueue
        self.cmdQ = cmdqueue
        self.gwAddress = gwaddress
        self.gwPort = gwport
        self.exitEvent = exitEvent
        self.nodeID = 7

        #init the logging
        #if not loginit == "":
        #    logging.config.fileConfig(loginit)
        #    self.logger = logging.getLogger('cmdEvent')
        #else:
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)
        fh = logging.FileHandler("client_node.log")
        fh.setLevel(logging.DEBUG)
        ch = logging.StreamHandler()
        ch.setLevel(logging.WARNING)
        formatter = logging.Formatter('%(asctime)s: %(message)s')
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        self.logger.addHandler(fh)
        self.logger.addHandler(ch)

        #get MAC address for node registration.
        self.mac = self.getMac()
        self.logger.info("\n\nStarting new session using MAC address: %s", self.mac)

    def getMac(self):
        #check macaddress #from: https://stackoverflow.com/questions/159137/getting-mac-address
        mac=get_mac()
        macStr=':'.join(("%012X" % mac)[i:i+2] for i in range(0, 12, 2))
        return macStr

    def rcv(self, clientsocket):
        """Receieve a max of 1024 bytes from the socket. Return a tuplle with error condiation and msg"""
        response=""
        error=False
        try:
            responsePkt = clientsocket.recv(1024)
            response = responsePkt.decode('ascii')
        except:
            error=True
            self.logger.warning("Error receiving from socket %s:%d",self.gwAddress,self.gwPort)
        return (error, response)

    def snd(self, clientsocket, msg):
        error=False
        try:
            clientsocket.send(msg.encode('ascii'))
        except:
            error=True
            self.logger.warning("\nError sending to socket: %s:%d",self.gwAddress,self.gwPort)
        return error

    def getTempMsg(self):

        #get a temp frome the queue, blocking if necessary.
        try: 
            temp = self.tempQ.get(True,3)
        except:
            self.logger.error("Timout waiting for temperature update")
            self.exitEvent.set()
            tempStr = False
        else:
            tempStr = "Temp: "+str(temp)

        return tempStr

    def validateCommmand(self, cmd):
        #not exiting, so split header and command. 
        valid = False
        header=cmd.split(" ")[0]
        headerLen=len(header)
        msg=cmd[headerLen+1:]
        msgLen=len(msg)
        
        #Write received message
        #why sys.stdout?
        #sys.stdout.write(msg)

        self.logger.info("Recieved command %s from gw %s%d", cmd, self.gwAddress, self.gwPort)
        self.logger.debug("Parsed Message length %s", msgLen)

        #Process commands
        #commands from gw { "": "Notset", "-1": "FAN-OFF", "-2": "FAN-ON" }

        if header == "Command:":
            self.logger.debug("Valid command header")

            if msg == "-1" or msg == "-2" or msg =="":
                self.logger.debug("Valid msg %s found",msg)
                valid = True
            else: 
                try:
                    self.logger.debug("Msg not -1,-2, or empty, trying int()")
                    msg = int(msg)
                except:
                    self.logger.error("Failed converting command set point to integer")
                    #No raise exception.. will set running to zero when valid is returned false.
                else:
                    valid = True

        self.logger.debug("Returning valid: %s, msg: %s",str(valid), msg)
        return (valid, msg)
        
    def handshakErrorHandler(self,msg,sock):
        self.logger.error(msg)
        if not (sock==-1):
            sock.close()
        self.exitEvent.set()
        self.cmdQ.put("EXIT")
        raise Exception(msg)


    def handshake(self):

        #init the socket
        self.sock = socket(AF_INET, SOCK_STREAM)
        try:  
            #remember that the arguement needs to be a tuple.
            self.sock.connect((self.gwAddress, self.gwPort))
        except socket:
            errMsg = "Socket error occured connectiong to GW %s:%d" % (self.gwaddress, self.gwPort)
            self.handshakErrorHandler(errMsg,-1)

        except:
            errMsg = "Unknown error connecting to GW %s:%d" % (self.gwAddress, self.gwPort)
            self.handshakErrorHandler(errMsg,-1)

        #no exceptions, log connection
        self.logger.info("Connected to %s:%d", self.gwAddress, self.gwPort)

        #Format first message to send.
        #using raspberry py nummber 7
        msg = "Node: "+str(self.nodeID)
        error = self.snd(self.sock,msg)
        if(error):
            errMsg = "Error sending node setup info to GW %s:%d" % (self.gwAddress,self.gwPort)
            self.handshakErrorHandler(errMg,self.sock)

        #Wait for gw ack
        (error, response) = self.rcv(self.sock)
        if error == True:
            errMsg = "No ack from GW %s:%d while registering node." % (self.gwAddress,self.gwPort)
            self.handshakErrorHandler(errMg,self.sock)


        self.logger.info("ACK received from GW %s:%d for node registration", self.gwAddress,self.gwPort)

        #Send first Temp Pack
        tmsg = self.getTempMsg()
        if tmsg:
            error = self.snd(self.sock, tmsg)
            if error: 
                errMsg = "Error sending initial temp packet to gw %s:%d" %(self.gwAddress,self.gwPort)
                self.handshakErrorHandler(errMg,self.sock)


            #get GW response for initial temp.
            (error, response) = self.rcv(self.sock)
            if error:
                errMsg = "Invalid ack recieved for initial temp packet from gw %s:%d" %(self.gwAddress,self.gwPort)
                self.handshakErrorHandler(errMg,self.sock)

            
            self.logger.info("Ack for initial temp recieved from gw %s:%d",self.gwAddress,self.gwPort)

        #start operations
        self.operate(self.sock)  

    def operate(self, clientsocket):

        #initial connection ready, now run continuously
        cnt=0
        while not self.exitEvent.is_set():
            #not sure what the count is for.
            cnt=cnt+1
            #print "DEBUG while cnt="+str(cnt)
       
            #Start loop by sending temperature packet.
            msg = self.getTempMsg()

            if msg:
                error = self.snd(clientsocket, msg)
                if error:
                    self.logger.error("Error sending temp packet to GW %s:%d", self.gwAddress, self.gwPort)
                    self.exitEvent.set()
                    continue
        
                #receive command; command packet=="command: <command>" , where command=(-1==FANOFF, -2==FANON, temp==tempSetpoint)
                (error, cmdPkt) = self.rcv(clientsocket)
                if(error):
                    self.logger.error("Error receiving command packet from GW %s:%d", self.gwAddress, self.gwPort)
                    self.exitEvent.set()
                    continue
        
                #Check entire packet for exit command 
                if(cmdPkt=="servuser: EXIT"):
                    self.logger.info("Recieved \"Exit\" from GW %s:%d", self.gwAddress, self.gwPort)
                    print "server Exit"
                    self.exitEvent.set()
                    continue

                (valid, cmd) = self.validateCommmand(cmdPkt)
                if valid:
                    self.cmdQ.put(cmd)

                else:
                    self.logger.info("Recieved invalid command from GW %s:%d", self.gwAddress, self.gwPort)
                    self.exitEvent.set()

                time.sleep(1.0)

        self.logger.info("Running state changed to Exit.")
        self.cmdQ.put("EXIT")
        self.sock.close()
        print("Exiting...\n")
        os._exit(0)


