#include <stdio.h>

#define SUCCESS    0
#define CHAR_RED   "\033[31m"
#define CHAR_RESET "\033[0m"

#define NUM_SYLLABLES 120
char *Syllables[] = { 
        "bah",  "bay",  "bee",  "buy",   "boh",  "boo",
        "pah",  "pay",  "pee",  "pie",   "poh",  "poo",
        "tah",  "tay",  "tee",  "tie",   "toe",  "too",
        "dah",  "day",  "dee",  "die",   "doh",  "doo",
        "fah",  "fay",  "fee",  "fie",   "foh",  "foo",
        "vah",  "vay",  "vee",  "vie",   "voh",  "voo",
        "kah",  "kay",  "key",  "kie",   "koh",  "koo",
        "gah",  "gay",  "gee",  "guy",   "goh",  "goo",
        "shaw", "chay", "chee", "chai",  "cho",  "choo",
        "thaw", "thay", "thee", "thigh", "tho",  "thoo",
        "jaw",  "jay",  "jee",  "jie",   "joh",  "joo",
        "zhaw", "zhay", "zhee", "zhy",   "zhoh", "zhoo",
        "naw",  "nay",  "knee", "nye",   "no",   "new",
        "mah",  "may",  "mee",  "my",    "mow",  "moo",
        "wah",  "way",  "weea", "why",   "whoa", "woo",
        "yaw",  "yay",  "yee",  "yie",   "yoh",  "yoo",
        "zah",  "zay",  "zee",  "zee",   "zye",  "zoo",
        "saw",  "say",  "see",  "sigh",  "so",   "sue",  
        "rah",  "ray",  "ree",  "rye",   "roh",  "roo",
        "lah",  "lay",  "lee",  "lie",   "low",  "loo"
};




int main(int argc, char *argv[]) 
{
        return SUCCESS;
}
