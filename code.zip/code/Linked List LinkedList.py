#Linked-List
#
# CS3021 LL Project
#
#   LinkedList is provided complete



class LinkedList(object):


    class Node(object):

        def __init__(self, dataIn):
            self.data = dataIn
            self.nextNode = None

        @property
        def nextNode(self):
            return self.__nextNode

        @nextNode.setter
        def nextNode(self, nextIn):
            #allows None, but no other non-Node assignment
            if nextIn and not isinstance(nextIn, self.__class__):
                raise RuntimeError(str(nextIn) + ' is not a linked-list Node.')
            self.__nextNode = nextIn



    def __init__(self, dataItem):
        self.head = self.Node(dataItem)




    def read(self, index):
        ''' returns data at the provided index, or None if index beyond end of list '''
        current = self.head
        i = 0
        while i < index and current.nextNode:
            current = current.nextNode
            i += 1

        if i == index:
            return current.data
        else:
            return None


    def indexOf(self, value):
        ''' returns index of first matching value, or None if value not found'''
        current = self.head
        i = 0
        while not current.data == value and current.nextNode:
            current = current.nextNode
            i += 1

        if current.data == value:
            return i
        else:
            return None


    def insertAtIndex(self, index, dataItem):
        ''' inserts new Node at index,
            appends to end if index beyond end of list '''


        if index == 0:
            newNode = self.Node(dataItem)
            newNode.nextNode = self.head
            self.head = newNode
        else:
            current = self.head
            i = 0
            while i < index-1 and current.nextNode:
                current = current.nextNode
                i += 1

            newNode = self.Node(dataItem)
            if i == index-1:
                newNode.nextNode = current.nextNode
                current.nextNode = newNode
            else:
                current.nextNode = newNode




    def deleteAtIndex(self, index):
        ''' deletes Node at index, silent completion,
              no error generated if index beyond end of list '''

        if index == 0:
            self.head = self.head.nextNode
        else:
            current = self.head
            i = 0
            while i < index-1 and current.nextNode:
                current = current.nextNode
                i += 1


            if i == index-1 and current.nextNode:
                current.nextNode = current.nextNode.nextNode
            elif i == index-1:
                current.nextNode = None





    def __str__(self):
        current = self.head
        result = str(current.data)

        while current.nextNode:
            current = current.nextNode
            result += ', ' + str(current.data)

        return result




##########################################################
#main


if __name__=="__main__":
    llist = LinkedList(0)
    print(llist)
    print('read(0)', llist.read(0))

    llist.insertAtIndex(99,1)
    print('insertAtIndex(99,1)', llist)
    print('read(0)', llist.read(0))
    print('read(1)', llist.read(1))
    print('read(99)', llist.read(99))
    print('read(2)', llist.read(2))

    print('indexOf(0)', llist.indexOf(0))
    print('indexOf(1)', llist.indexOf(1))
    print('indexOf(2)', llist.indexOf(2))
    print('indexOf(99)', llist.indexOf(99))

    llist.insertAtIndex(99,2)
    print('insertAtIndex(99,2)', llist)
    print('read(2)', llist.read(2))

    llist.insertAtIndex(0, 'n')
    print('insertAtIndex(0, n)', llist)

    llist.insertAtIndex(2,22)
    print('insertAtIndex(2,22)', llist)
    llist.insertAtIndex(2,222)
    print('insertAtIndex(2,222)', llist)

    llist.deleteAtIndex(4)
    print('deleteAtIndex(4)', llist)
    llist.deleteAtIndex(2)
    print('deleteAtIndex(2)', llist)
    llist.deleteAtIndex(4)
    print('deleteAtIndex(4)', llist)
    llist.deleteAtIndex(0)
    print('deleteAtIndex(0)', llist)
