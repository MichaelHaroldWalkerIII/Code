listln = [2, 3, 4, 4, 1, 2]

def mySort(listln):
    if len(listln)<2:
        return listln
    pivot = listln[0]
    head = mySort([element for element in listln if element<pivot])
    pivots = [element for element in listln if element == pivot]
    tail = mySort([element for element in listln if element > pivot])
    return head+pivots+tail

print(mySort(listln))
