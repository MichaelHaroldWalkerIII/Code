#!/usr/bin/python
class Node:
    def __init__(self, val):
        self.l = None
        self.r = None
        self.v = val

class BinaryTree(object):
    ''' very simplified and partially implemented Binary Tree.
        This BinaryTree implementation is never empty.
        Duplicate values not added to the tree (set-like behavior).'''

    def __init__(self, initialValue):
        #we code the BinaryTree to hold BinaryTrees on the left and right
        #  a true recursive implementation
        self.__left  = None
        self.__right = None
        self.__value = initialValue
        self.root = None

    def getRoot(self):
        return self.root

    def __str__(self):
                    #Python's ternary conditional statement
        leftChild = str(self.__left) if self.__left else 'None'
        rightChild = str(self.__right) if self.__right else 'None'
        return '(' + leftChild + ' <- ' + str(self.__value) + ' -> ' + rightChild + ')'

    def add(self, val):
        ''' adds a value to the BinaryTree.  With respect to values the tree
               behaves as a mathematical Set. '''
        if(self.root == None):
            self.root = Node(val)
        else:
            self._add(val, self.root)
        pass

    def _add(self, val, node):
        if(val < node.v):
            if(node.l != None):
                self._add(val, node.l)
            else:
                node.l = Node(val)
        else:
            if(node.r != None):
                self._add(val, node.r)
            else:
                node.r = Node(val)

    def find(self, val):
        ''' returns True if queryValue is found in the BinaryTree, False otherwise'''
        if(self.root != None):
            return self._find(val, self.root)
        else:
            return None
        pass

    def _find(self, val, node):
        if(val == node.v):
            return node
        elif(val < node.v and node.l != None):
            self._find(val, node.l)
        elif(val > node.v and node.r != None):
            self._find(val, node.r)

#################################
#################################
#################################
#this kicks off the program and assigns the argument to a variable
#
if __name__=="__main__":


    tree = BinaryTree(3)
    print('\n', tree)
    print('expect')
    print(' (None <- 3 -> None)')


    print('\nadding', 3)
    tree.add( 3 )
    print(tree)
    print('expect')
    print('(None <- 3 -> None)')

    print ('\nfind 3?  ', tree.find(3) )
    print ('\nfind 1?  ', tree.find(1) )
    print ('\nfind 4?  ', tree.find(4) )

    print('\nadding', 4)
    tree.add( 4 )
    print(tree)
    print('expect')
    print('(None <- 3 -> (None <- 4 -> None))')

    print('\nadding', 0)
    tree.add( 0 )
    print(tree)
    print('expect')
    print('((None <- 0 -> None) <- 3 -> (None <- 4 -> None))')

    print('\nadding', 8)
    tree.add( 8 )
    print(tree)
    print('expect')
    print('((None <- 0 -> None) <- 3 -> (None <- 4 -> (None <- 8 -> None)))')

    print('\nadding', 2)
    tree.add( 2 )
    print(tree)
    print('expect')
    print('((None <- 0 -> (None <- 2 -> None)) <- 3 -> (None <- 4 -> (None <- 8 -> None)))')

    print ('\nfind 4?  ', tree.find(4) )
    print ('\nfind 5?  ', tree.find(5) )
    print ('\nfind 1?  ', tree.find(1) )
    print ('\nfind 0?  ', tree.find(0) )
    print ('\nfind 2?  ', tree.find(2) )
    print ('\nfind 8?  ', tree.find(8) )
    print ('\nfind -1?  ', tree.find(-1) )
    print ('\nfind 9?  ', tree.find(9) )
